//
//  EdvoraSampleApp.swift
//  EdvoraSample
//
//  Created by Ummer.Manjeri on 25/11/21.
//

import SwiftUI

@main
struct EdvoraSampleApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
